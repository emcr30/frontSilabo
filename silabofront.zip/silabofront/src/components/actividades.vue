<template>
  <div class="silabo-container">
    <!-- Sección VII: Actividades -->
    <div class="section">
      <h2 class="section-title">VII. ACTIVIDADES (sean en investigación formativa, RSU, proyección, extensión, otro)</h2>
      <div class="actividades-box">
        <div v-for="(actividad, index) in silabo.actividades" :key="index" class="actividad">
          <h3>{{ actividad.titulo }}</h3>
          <p>{{ actividad.descripcion }}</p>
        </div>
      </div>
    </div>

    <!-- Sección VIII: Criterios de Evaluación -->
    <div class="section">
      <h2 class="section-title">VIII. CRITERIOS DE EVALUACIÓN</h2>
      <div class="evaluacion-table">
        <table>
          <thead>
            <tr>
              <th>EVALUACIÓN</th>
              <th>PESO</th>
              <th>FECHA DE CONSOLIDACIÓN</th>
              <th>DESCRIPCIÓN DE LA EVALUACIÓN</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="criterio in silabo.criteriosEvaluacion" :key="criterio.id">
              <td>{{ criterio.evaluacion }}</td>
              <td>{{ criterio.peso }}</td>
              <td>{{ criterio.fechaConsolidacion }}</td>
              <td>
                <ul>
                  <li v-for="(desc, i) in criterio.descripcion" :key="i">{{ desc }}</li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Sección de Firma -->
    <div class="firma-section">
      <div class="fecha">
        <p>Fecha: {{ fechaActual }}</p>
      </div>
      <div class="firma">
        <p>Firma del docente</p>
        <div class="firma-container">
          <img v-if="firmaUrl" :src="firmaUrl" alt="Firma del docente" class="firma-img" />
          <div v-else class="firma-upload" @click="abrirSelectorArchivo">
            <span>Agregar firma</span>
            <input type="file" ref="firmaInput" @change="cargarFirma" accept="image/*" style="display: none" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ActividadesSilabo',
  data() {
    return {
      silabo: null,
      firmaUrl: null,
      fechaActual: this.obtenerFechaActual()
    };
  },
  created() {
    // Cargar el JSON
    this.cargarSilabo();
  },
  methods: {
    cargarSilabo() {
      // Asumiendo que el archivo JSON está en /public
      fetch('/silabo.json')
        .then(response => response.json())
        .then(data => {
          this.silabo = data;
        })
        .catch(error => {
          console.error('Error al cargar el silabo:', error);
        });
    },
    obtenerFechaActual() {
      const hoy = new Date();
      const dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
      const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
      
      const diaSemana = dias[hoy.getDay()];
      const dia = hoy.getDate();
      const mes = meses[hoy.getMonth()];
      const anio = hoy.getFullYear();
      
      return `${diaSemana}, ${dia} de ${mes} de ${anio}`;
    },
    abrirSelectorArchivo() {
      this.$refs.firmaInput.click();
    },
    cargarFirma(event) {
      const file = event.target.files[0];
      if (file) {
        this.firmaUrl = URL.createObjectURL(file);
      }
    }
  }
};
</script>

<style scoped>
.silabo-container {
  font-family: Arial, sans-serif;
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}

.section {
  margin-bottom: 30px;
}

.section-title {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 15px;
}

.actividades-box {
  border: 1px solid #000;
  padding: 15px;
  margin-bottom: 30px;
}

.actividad h3 {
  font-weight: bold;
  margin-bottom: 5px;
}

.evaluacion-table {
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #000;
}

th, td {
  border: 1px solid #000;
  padding: 8px;
  text-align: left;
  vertical-align: top;
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.firma-section {
  margin-top: 50px;
}

.fecha {
  margin-bottom: 30px;
}

.firma p {
  margin-bottom: 10px;
}

.firma-container {
  width: 300px;
  height: 100px;
  border: 1px solid #ccc;
  position: relative;
  overflow: hidden;
}

.firma-img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.firma-upload {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  cursor: pointer;
  background-color: #f9f9f9;
}

ul {
  margin: 0;
  padding-left: 20px;
}
</style>