<template>
  <div>
    <Silabo />
    <UnidadesAprendizaje />
  </div>
</template>

<script setup>
import Silabo from './components/silabo.vue'
import UnidadesAprendizaje from './components/unidades.vue'
import Actividades from './components/actividades.vue'
</script>